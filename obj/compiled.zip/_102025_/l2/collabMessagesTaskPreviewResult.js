/// <mls fileReference="_102025_/l2/collabMessagesTaskPreviewResult.ts" enhancement="_102027_/l2/enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { CollabLitElement } from '/_100554_/l2/collabLitElement.js';
let CollabMessageTaskPreviewResult = class CollabMessageTaskPreviewResult extends CollabLitElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`collab-messages-task-preview-result-102025{display:block;background:#ffffff;position:relative;height:100%;color:#3c3c3c}collab-messages-task-preview-result-102025 .tab-header{display:flex;justify-content:space-between;border-bottom:1px solid #ccc;background-color:#f0f0f0;overflow:hidden;flex-shrink:0}collab-messages-task-preview-result-102025 .tab-group-left{display:flex;overflow-x:auto;flex:1;min-width:0;scrollbar-width:thin}collab-messages-task-preview-result-102025 .tab-group-left::-webkit-scrollbar{height:6px}collab-messages-task-preview-result-102025 .tab-group-left::-webkit-scrollbar-thumb{background-color:var(--grey-color-darker);border-radius:4px}collab-messages-task-preview-result-102025 .tab-group-right{display:flex;flex-shrink:0}collab-messages-task-preview-result-102025 .tab-button{padding:10px 16px;cursor:pointer;background:none;border:none;border-right:1px solid #ddd;font-size:14px;transition:background-color .2s ease;display:flex;flex-direction:column}collab-messages-task-preview-result-102025 .tab-button:hover{background-color:#e0e0e0}collab-messages-task-preview-result-102025 .tab-button.active{background-color:#ffffff;font-weight:bold;border-bottom:2px solid #007bff}collab-messages-task-preview-result-102025 .tab-content{position:relative;padding:0;margin:0;background-color:#ffffff;display:flex;height:100%;flex-direction:column;font-size:14px;overflow-y:auto}collab-messages-task-preview-result-102025 .containerinputs{display:flex;flex-direction:column;gap:.5rem;align-items:center;padding:1rem}collab-messages-task-preview-result-102025 .containerinputs details{width:100%;max-width:900px;border:1px solid #e0e0e0;border-radius:8px;background-color:#fafafa;box-shadow:0 2px 8px rgba(0,0,0,0.05);font-family:'Inter',sans-serif;transition:all .3s ease}collab-messages-task-preview-result-102025 .containerinputs details[open] .title{display:none}collab-messages-task-preview-result-102025 .containerinputs details .chevron{transition:transform .3s}collab-messages-task-preview-result-102025 .containerinputs details[open] .chevron{transform:rotate(90deg)}collab-messages-task-preview-result-102025 .containerinputs details[open] .moveelement{display:none !important}collab-messages-task-preview-result-102025 .containerinputs details summary{position:relative;cursor:pointer;padding:1rem;border-bottom:1px solid #e0e0e0;display:flex;align-items:center;justify-content:space-between}collab-messages-task-preview-result-102025 .containerinputs details summary:hover .moveelement{display:flex}collab-messages-task-preview-result-102025 .containerinputs details summary .trash{z-index:9999}collab-messages-task-preview-result-102025 .containerinputs details summary .pheader{width:100%;display:flex;justify-content:space-between;align-items:center}collab-messages-task-preview-result-102025 .containerinputs details summary .pheader .title{margin-left:1rem}collab-messages-task-preview-result-102025 .containerinputs details summary .pheader .type .typeMode{appearance:none;padding:.4rem 1rem;font-size:.95rem;border:1px solid #ccc;border-radius:6px;background-color:white;transition:border .3s ease}collab-messages-task-preview-result-102025 .containerinputs details>div{padding:1rem}collab-messages-task-preview-result-102025 .containerinputs details>div pre.content{width:calc(100% - 2rem);border:none;resize:vertical;padding:1rem;font-size:.95rem;font-family:'Fira Code',monospace;background-color:#fff;border-radius:6px;color:#333;box-shadow:inset 0 1px 2px rgba(0,0,0,0.05);line-height:1.5;word-break:break-word;white-space:pre-wrap}collab-messages-task-preview-result-102025 ul{list-style:none;padding:1rem;margin:1rem 0;border-radius:12px;color:#333}collab-messages-task-preview-result-102025 ul li{margin-bottom:.75rem;padding:.5rem .75rem;background:white;border-radius:8px;transition:background .3s}collab-messages-task-preview-result-102025 ul li code{font-family:'Courier New',monospace;background-color:#eee;padding:2px 6px;border-radius:4px}`);
        this.message = null;
        this.task = null;
        this.step = null;
        this.mode = 'result';
    }
    render() {
        if (!this.step) {
            return html `<p>Step not Found.</p>`;
        }
        return html `
            <div style="height: calc(100% - 41px);">
                <div class="tab-header">
                    <div class="tab-group-left">
                        <button
                            class="tab-button ${this.mode === 'info' ? 'active' : ''}" @click=${() => this.selectTabInfo()} >
                            Info                            
                        </button>
                        <button
                            class="tab-button ${this.mode === 'result' ? 'active' : ''}" @click=${() => this.selectTabResult()} >
                            Result                            
                        </button>
                    </div>
                </div>
                <div class="tab-content">
                    ${this.renderMode()}
                    
                </div>
            </div>
        `;
    }
    renderMode() {
        switch (this.mode) {
            case 'result': return this.renderResults();
            case 'info': return this.renderInfo();
            default: return this.renderInfo();
        }
    }
    renderInfo() {
        if (!this.task || !this.step)
            return html `Not found!`;
        const aux = this.step.status === 'in_progress' ? '(in progress)' : '';
        return html `
        <div class="containerinputs">
            <details open>
                <summary> ${this.renderSummary('Result' + aux)} </summary>
                <ul>
                    <li>
                        #${this.step.stepId} - ${this.step.type} - ${this.step.status}
                    </li>
                </ul>
            </details>
            <details>
                <summary> ${this.renderSummary('Task details')}</summary>
                <ul>
                    <li>
                        <header>
                                <h2>${this.task.PK}</h2>
                                <small>Status: ${this.task.status} | Última atualização: ${new Date(this.task.last_updated).toLocaleString()}</small>
                        <br/><small>${this.task.title}</small>
                        </header>
                    </li>
                </ul>
            </details>
            <details>
                <summary> ${this.renderSummary('Message details')}</summary>
                <ul>
                    <li>
                        <pre>
                            ${JSON.stringify(this.message, null, 2)}
                        </pre>
                    </li>
                </ul>
            </details>
        </div>
        `;
    }
    renderSummary(title) {
        return html `
            <div class="pheader">
                <div style="display:flex; align-items: center;gap:.5rem">
                    <span>
                        ${title}
                    </span>
                </div>
                <div style="display:flex; gap:.5rem">
                    <div class="chevron">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" style="width:10px"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d="M310.6 233.4c12.5 12.5 12.5 32.8 0 45.3l-192 192c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L242.7 256 73.4 86.6c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0l192 192z"/></svg>
                    </div>
                </div>
            </div>
        `;
    }
    renderResults() {
        if (!this.step)
            return html `Not found step`;
        const nextOptions = [];
        if (this.step.interaction?.payload) {
            nextOptions.push(...this.step.interaction.payload);
        }
        if (this.step.nextSteps) {
            nextOptions.push(...this.step.nextSteps);
        }
        return html `
        <div style="padding:1rem">
            ${this.step.result}
        </div>
        `;
    }
    //------IMPLEMENTATION----------
    selectTabInfo() {
        this.mode = 'info';
    }
    selectTabResult() {
        this.mode = 'result';
    }
};
__decorate([
    property({ type: Object })
], CollabMessageTaskPreviewResult.prototype, "message", void 0);
__decorate([
    property({ type: Object })
], CollabMessageTaskPreviewResult.prototype, "task", void 0);
__decorate([
    property({ type: Object })
], CollabMessageTaskPreviewResult.prototype, "step", void 0);
__decorate([
    state()
], CollabMessageTaskPreviewResult.prototype, "mode", void 0);
CollabMessageTaskPreviewResult = __decorate([
    customElement('collab-messages-task-preview-result-102025')
], CollabMessageTaskPreviewResult);
export { CollabMessageTaskPreviewResult };
